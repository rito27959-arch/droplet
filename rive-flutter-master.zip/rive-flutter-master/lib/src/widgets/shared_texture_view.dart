import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:rive/src/widgets/inherited_widgets.dart';
import 'package:rive_native/rive_native.dart';

/// Renders the [artboard] to a [sharedTexture].
///
/// See [RivePanel]. Only useful when using `Factory.rive`.
class SharedTextureView extends StatefulWidget {
  final Artboard artboard;
  final SharedTextureArtboardWidgetPainter painter;
  final SharedRenderTexture sharedTexture;
  final int drawOrder;
  const SharedTextureView({
    required this.artboard,
    required this.painter,
    required this.sharedTexture,
    required this.drawOrder,
    super.key,
  });

  @override
  State<SharedTextureView> createState() => _SharedTextureViewState();
}

class _SharedTextureViewState extends State<SharedTextureView> {
  @override
  void initState() {
    super.initState();
    widget.painter.artboardChanged(widget.artboard);
  }

  @override
  void didUpdateWidget(covariant SharedTextureView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.artboard != widget.artboard) {
      widget.painter.artboardChanged(widget.artboard);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SharedTextureViewRenderer(
      renderTexturePainter: widget.painter,
      sharedTexture: widget.sharedTexture,
      devicePixelRatio: MediaQuery.devicePixelRatioOf(context),
      drawOrder: widget.drawOrder,
    );
  }
}

class SharedTextureViewRenderer extends LeafRenderObjectWidget {
  final RenderTexturePainter renderTexturePainter;
  final SharedRenderTexture sharedTexture;
  final double devicePixelRatio;
  final int drawOrder;

  const SharedTextureViewRenderer({
    super.key,
    required this.renderTexturePainter,
    required this.sharedTexture,
    required this.devicePixelRatio,
    required this.drawOrder,
  });

  @override
  RenderObject createRenderObject(BuildContext context) {
    return SharedTextureViewRenderObject(sharedTexture)
      ..painter = renderTexturePainter
      ..scrollPosition = Scrollable.maybeOf(context)?.position
      ..devicePixelRatio = devicePixelRatio
      ..drawOrder = drawOrder;
  }

  @override
  void updateRenderObject(
    BuildContext context,
    covariant SharedTextureViewRenderObject renderObject,
  ) {
    renderObject
      ..shared = sharedTexture
      ..painter = renderTexturePainter
      ..scrollPosition = Scrollable.maybeOf(context)?.position
      ..devicePixelRatio = devicePixelRatio
      ..drawOrder = drawOrder;
  }

  @override
  void didUnmountRenderObject(
      covariant SharedTextureViewRenderObject renderObject) {
    renderObject.painter = null;
  }
}

class SharedTextureViewRenderObject extends RiveNativeRenderBox
    implements SharedTexturePainter {
  SharedRenderTexture _shared;

  SharedTextureViewRenderObject(this._shared)
      : super(UnimplementedRenderTexture()) {
    _shared.texture.addTextureChangedListener(_onRiveTextureChanged);
  }

  int _drawOrder = 1;
  int get drawOrder => _drawOrder;
  set drawOrder(int value) {
    if (_drawOrder == value) {
      return;
    }
    _drawOrder = value;
    if (!attached) {
      // createRenderObject's cascade runs before attach() adds this painter;
      // addPainter sorts on attach, so there's nothing to restack yet.
      return;
    }
    // Stacking lives in the shared texture's painter list, which is only
    // sorted when a painter attaches — an order change on a mounted widget
    // must re-sort (and repaint) explicitly.
    _shared.painterOrderChanged();
  }

  SharedRenderTexture get shared => _shared;
  set shared(SharedRenderTexture value) {
    if (_shared == value) {
      return;
    }
    _shared.texture.removeTextureChangedListener(_onRiveTextureChanged);
    _shared.removePainter(this);
    _shared = value;
    _shared.texture.addTextureChangedListener(_onRiveTextureChanged);
    _shared.addPainter(this);
    markNeedsPaint();
  }

  bool _shouldAdvance = true;

  @override
  bool get shouldAdvance => _shouldAdvance;

  // The per-widget ticker inherited from [RiveNativeRenderBox] is never
  // started — the shared texture owns a single ticker that drives every
  // painter. Mirror the shared ticker's state here so painter listeners
  // (e.g. state-machine advance requests) check the right flag.
  @override
  bool get isTickerActive => _shared.isTickerActive;

  // Repaint on texture change. (markNeedsLayout would assert: the panel
  // notifies us from its performLayout, and our size is layout-independent.)
  void _onRiveTextureChanged() => markNeedsPaint();

  @override
  void paintTexture(double elapsedSeconds, {bool forceShouldAdvance = false}) {
    // do nothing. we draw to the shared texture.
  }

  // Forward ticker control to the shared texture. The inherited `_ticker`
  // field stays unused; painter listeners attached by [RiveRenderBox.painter]
  // call through `restartTickerIfStopped → startTicker`, which now wakes the
  // shared ticker instead of an isolated per-widget one.
  @override
  void startTicker() {
    _shared.startTicker();
  }

  @override
  void stopTicker() {
    // Individual widgets never stop the shared ticker — the shared paint
    // pass decides when to stop based on every painter's settled state.
  }

  @override
  bool get sizedByParent => true;

  @override
  Size computeDryLayout(BoxConstraints constraints) => constraints.smallest;

  @override
  void paint(PaintingContext context, Offset offset) {
    super.paint(context, offset);
    _shared.schedulePaint();
  }

  ScrollPosition? _scrollPosition;
  set scrollPosition(ScrollPosition? v) {
    if (identical(v, _scrollPosition)) return;
    _unsubscribe();
    _scrollPosition = v;
    _subscribe();
    _scheduleCheck();
  }

  void _subscribe() => _scrollPosition?.addListener(_scheduleCheck);
  void _unsubscribe() => _scrollPosition?.removeListener(_scheduleCheck);

  void _scheduleCheck() {
    if (!attached) return;
    markNeedsPaint();
  }

  @override
  void dispose() {
    _shared.removePainter(this);
    _shared.texture.removeTextureChangedListener(_onRiveTextureChanged);
    super.dispose();
  }

  @override
  bool paintIntoSharedTexture(RenderTexture texture, double elapsedSeconds) {
    final panelKeyContext = shared.panelKey.currentContext;
    if (panelKeyContext == null) {
      // Can't compute a transform without the panel laid out yet — bail and
      // report settled. A subsequent layout will [markNeedsPaint] which kicks
      // the shared ticker via the painter's listener.
      _shouldAdvance = false;
      return false;
    }
    final panelRenderBox = panelKeyContext.findRenderObject() as RenderBox;

    // Read the transform fresh every paint. The cached scale on
    // [RiveNativeRenderBox] (`desiredTransformWidth/HeightScale`) only
    // refreshes when this RenderObject's own paint() runs, which composited
    // ancestors (RepaintBoundary inside PageView, Opacity layers, etc.) can
    // skip while still animating a Transform.scale — leaving the cached
    // scale stale while localToGlobal still tracks the live transform.
    //
    // getTransformTo handles non-ancestor targets (panel is typically a
    // sibling, not an ancestor) by walking both sides to the common
    // ancestor and inverting. Any ancestor transform shared with the panel
    // cancels out — the texture widget re-applies it at composite time.
    //
    // Build the full 2D affine from the Matrix4 (preserving rotation, skew,
    // and mirror) rather than reading only the scale diagonal — otherwise
    // the texture content drawn here desyncs from how the Texture widget
    // composites at the widget tree's real transform.
    final widgetToPanel =
        Mat2D.fromMat4(getTransformTo(panelRenderBox).storage);
    final dpr = devicePixelRatio;

    // Scale into the texture's actual pixels relative to the panel size, so
    // content keeps filling the texture while it lags the panel mid-resize.
    final (sx, sy) = texture.actualScale(
      panelRenderBox.size,
      fallbackX: dpr,
      fallbackY: dpr,
    );

    final renderer = texture.renderer;
    renderer.save();
    renderer.transform(Mat2D.fromScale(sx, sy).mul(widgetToPanel));
    _shouldAdvance = rivePainter?.paint(
          texture,
          dpr,
          size,
          elapsedSeconds,
        ) ??
        false;
    renderer.restore();
    return _shouldAdvance;
  }

  @override
  int get sharedDrawOrder => drawOrder;

  // Surfaced for the shared paint pass; this box's own render-box attach
  // never runs (its texture is an [UnimplementedRenderTexture]).
  @override
  Factory? get riveFactory => rivePainter?.riveFactory;

  @override
  void attach(PipelineOwner owner) {
    super.attach(owner);
    markNeedsLayout();
    _shared.addPainter(this);
  }

  @override
  void detach() {
    _unsubscribe();
    _scrollPosition = null;
    _shared.removePainter(this);
    super.detach();
  }
}

base class SharedTextureArtboardWidgetPainter
    extends ArtboardWidgetPainter<ArtboardPainter> {
  SharedTextureArtboardWidgetPainter(ArtboardPainter super.painter);

  void artboardChanged(Artboard artboard) => painter?.artboardChanged(artboard);
}
